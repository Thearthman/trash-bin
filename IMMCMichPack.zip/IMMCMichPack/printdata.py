def printdata (sortedList, avgSortedList, adList):
    print(sortedList)
    print(avgSortedList.sum())
    print(adList[len(adList) - 10:len(
        adList) - 1])
    print(min(adList))